$(function(){
	pageHeight();
	$(window).resize(function(){
		pageHeight();
	}).trigger('resize');

	function pageHeight(){
		$('.section').each(function(){
			var ww = $(window).width();
			var wh = $(window).height();
			$('.section').css({
				height:wh + 'px'
			});
			if(ww > 1024){
				$('.page2').css({
					height:wh*1.2 + 'px' 
				});
			} else {
				$('.page2').css({
					height:wh + 'px' 
				});
			}
			
		})
	}
	console.log($(window).height());
})
$('.slider').slick({
	centerMode: true,
	centerPadding: '0px',
	slidesToShow: 5,
	dots: true,
	responsive: [
	  {
		// breakpoint: 768,
		breakpoint: 1024,
		settings: {
			arrows: true,
			centerMode: true,
			centerPadding: '0px',
			slidesToShow: 3
		}
	  },
	  {
		// breakpoint: 480,
		breakpoint: 640,
		settings: {
			arrows: true,
			centerMode: true,
			centerPadding: '0px',
			slidesToShow: 1
		}
	  }
	]
});